const https = require('https');
const http = require('http');

exports.handler = async (event) => {
  console.log('Learning trigger invoked:', JSON.stringify(event));

  const baseUrl = process.env.API_BASE_URL || 'https://bcsf.chaptersdata.com';
  const apiKey = process.env.LEARNING_API_KEY;
  const url = new URL('/api/ai/learning/run', baseUrl);

  if (!apiKey) {
    console.error('LEARNING_API_KEY not configured - API call will be rejected');
  }

  const payload = JSON.stringify({
    forceRun: event.forceRun || false,
    skipWebResearch: event.skipWebResearch || false,
    source: event.source || 'eventbridge-schedule'
  });

  const headers = {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload)
  };

  // Add auth header if API key is configured
  if (apiKey) {
    headers['X-API-Key'] = apiKey;
  }

  const options = {
    hostname: url.hostname,
    port: url.port || (url.protocol === 'https:' ? 443 : 80),
    path: url.pathname,
    method: 'POST',
    headers: headers
  };

  return new Promise((resolve, reject) => {
    const client = url.protocol === 'https:' ? https : http;
    const req = client.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        console.log('API Response:', res.statusCode, data);
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({
            statusCode: 200,
            body: JSON.stringify({
              message: 'Learning triggered successfully',
              response: JSON.parse(data || '{}')
            })
          });
        } else {
          resolve({
            statusCode: res.statusCode,
            body: JSON.stringify({
              message: 'API returned error',
              response: data
            })
          });
        }
      });
    });

    req.on('error', (err) => {
      console.error('Request error:', err);
      reject(err);
    });

    req.write(payload);
    req.end();
  });
};
